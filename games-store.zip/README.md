# GameVault — Premium Static Games Store

Static HTML + Tailwind CSS + Vanilla JS gaming directory designed for GitHub Pages or Cloudflare Pages.

## Build

```bash
npm ci
npm run build
```

The starter ships a compiled `assets/css/tailwind.css` plus the source/build script. `npm run build` scans the static HTML/JS and emits a small Tailwind v4 utility bundle for production. The site has no runtime backend or database.

## Cloudflare Pages

- Build command: `npm run build`
- Build output directory: `.`
- Node version: `20`

## GitHub Pages

The included `.github/workflows/pages.yml` builds Tailwind and deploys the repository through GitHub Pages.

## Replace before production

Update the sample `example.com` URLs, game data in `assets/js/data.js`, artwork, legal pages, and external destination URLs. Verify every rating, bonus, withdrawal statement and structured-data field before publishing.
